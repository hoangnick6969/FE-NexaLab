import { z } from "zod";
export const VERSION = "1.0.0";
const part = z.object({
  id: z.string().min(1).max(60),
  type: z.enum(["battery", "resistor", "led", "switch"]),
  value: z.number().finite().min(0).max(100000).optional(),
  closed: z.boolean().optional(),
});
export const circuitSchema = z.object({
  nodes: z.array(part).min(1).max(24),
  edges: z.array(z.object({ source: z.string(), target: z.string() })).max(48),
});
export type CircuitState = z.infer<typeof circuitSchema>;
export function circuit(raw: unknown) {
  const state = circuitSchema.parse(raw);
  const nodes = state.nodes;
  if (new Set(nodes.map((n) => n.id)).size !== nodes.length)
    throw new Error("Mã linh kiện bị trùng");
  const battery = nodes.filter((n) => n.type === "battery");
  if (battery.length !== 1) throw new Error("MVP yêu cầu đúng một nguồn điện");
  const voltage = battery[0].value ?? 9;
  if (voltage < 1 || voltage > 24) throw new Error("Điện áp phải từ 1–24 V");
  const adjacency = new Map(nodes.map((n) => [n.id, [] as string[]]));
  const unique = new Set<string>();
  for (const e of state.edges) {
    if (
      !adjacency.has(e.source) ||
      !adjacency.has(e.target) ||
      e.source === e.target
    )
      throw new Error("Dây nối không hợp lệ");
    const key = [e.source, e.target].sort().join("|");
    if (unique.has(key)) throw new Error("Dây nối bị trùng");
    unique.add(key);
    adjacency.get(e.source)!.push(e.target);
    adjacency.get(e.target)!.push(e.target === e.source ? e.target : e.source);
  }
  const base = {
    version: VERSION,
    voltage,
    maxCurrentMa: 20,
    minimumResistance: Math.ceil(Math.max(0, voltage - 2) / 0.02),
  };
  const fail = (status: string) => ({
    ...base,
    current: 0,
    currentMa: 0,
    resistance: 0,
    ledState: "OFF",
    status,
    verdict: "not_passed",
    branches: [] as number[],
  });
  // Each path from one battery terminal (source edge) back to battery is a series branch.
  // Node canvas uses undirected loops: enumerate simple cycles through the sole source.
  const source = battery[0].id;
  const paths: string[][] = [];
  let visits = 0;
  const visit = (at: string, path: string[]) => {
    if (++visits > 10000)
      throw new Error(
        "Mạch quá phức tạp; hãy dùng nhánh nối tiếp/song song độc lập",
      );
    for (const next of adjacency.get(at)!) {
      if (next === source && path.length >= 3) {
        if (path[1] < path[path.length - 1]) paths.push([...path]);
        continue;
      }
      if (path.includes(next)) continue;
      if (paths.length > 16) throw new Error("Tối đa 16 nhánh");
      visit(next, [...path, next]);
    }
  };
  visit(source, [source]);
  if (!paths.length) return fail("OPEN_CIRCUIT");
  const active = paths.filter(
    (p) =>
      !p.some((id) => {
        const n = nodes.find((n) => n.id === id)!;
        return n.type === "switch" && !n.closed;
      }),
  );
  if (!active.length) return fail("SWITCH_OPEN");
  // Disjoint branches are supported; bridge/shared non-source nodes are rejected.
  const used = new Set<string>();
  for (const p of active)
    for (const id of p.slice(1)) {
      if (used.has(id))
        throw new Error(
          "Chỉ hỗ trợ nhánh nối tiếp/song song độc lập, không hỗ trợ mạch cầu",
        );
      used.add(id);
    }
  let hasLed = false,
    overload = false,
    anyOn = false;
  const branches = active.map((p) => {
    const parts = p.map((id) => nodes.find((n) => n.id === id)!);
    const resistance = parts
      .filter((n) => n.type === "resistor")
      .reduce((s, n) => s + (n.value ?? 330), 0);
    const leds = parts.filter((n) => n.type === "led").length;
    hasLed ||= leds > 0;
    const current =
      resistance === 0 ? null : Math.max(0, voltage - 2 * leds) / resistance;
    if (current === null || (leds > 0 && current > 0.02 + 1e-12))
      overload = true;
    if (
      leds > 0 &&
      current !== null &&
      current >= 0.001 &&
      current <= 0.02 + 1e-12
    )
      anyOn = true;
    return { resistance, current, leds };
  });
  const current = branches.some((b) => b.current === null)
    ? null
    : branches.reduce((s, b) => s + b.current!, 0);
  const status = overload
    ? "LED_OVERLOAD"
    : !hasLed
      ? "NO_LED"
      : anyOn
        ? "SAFE"
        : "LOW_CURRENT";
  return {
    ...base,
    current,
    currentMa: current === null ? null : Math.round(current * 1000000) / 1000,
    resistance: branches.length === 1 ? branches[0].resistance : null,
    ledState: overload ? "OVERLOAD" : anyOn ? "ON" : "OFF",
    status,
    verdict: overload ? "partial" : anyOn ? "passed" : "not_passed",
    branches,
  };
}
export const reactions = [
  {
    id: "mg-hcl",
    equation: "Mg + 2HCl → MgCl₂ + H₂",
    a: "Mg",
    b: "HCl",
    ratioA: 1,
    ratioB: 2,
    phenomenon: "Sủi bọt khí H₂",
    product: "H₂",
    color: "#e1eef4",
  },
  {
    id: "caco3-hcl",
    equation: "CaCO₃ + 2HCl → CaCl₂ + CO₂ + H₂O",
    a: "CaCO₃",
    b: "HCl",
    ratioA: 1,
    ratioB: 2,
    phenomenon: "Sủi bọt khí CO₂",
    product: "CO₂",
    color: "#e1eef4",
  },
  {
    id: "naoh-hcl",
    equation: "NaOH + HCl → NaCl + H₂O",
    a: "NaOH",
    b: "HCl",
    ratioA: 1,
    ratioB: 1,
    phenomenon: "Trung hòa; chỉ thị thay đổi theo chất dư",
    product: "NaCl",
    color: "#ead2ed",
  },
  {
    id: "cuso4-naoh",
    equation: "CuSO₄ + 2NaOH → Cu(OH)₂↓ + Na₂SO₄",
    a: "CuSO₄",
    b: "NaOH",
    ratioA: 1,
    ratioB: 2,
    phenomenon: "Kết tủa xanh Cu(OH)₂",
    product: "Cu(OH)₂",
    color: "#37a6e8",
  },
  {
    id: "nacl-agno3",
    equation: "NaCl + AgNO₃ → AgCl↓ + NaNO₃",
    a: "NaCl",
    b: "AgNO₃",
    ratioA: 1,
    ratioB: 1,
    phenomenon: "Kết tủa trắng AgCl",
    product: "AgCl",
    color: "#f5f5f1",
  },
  {
    id: "fe-cuso4",
    equation: "Fe + CuSO₄ → FeSO₄ + Cu",
    a: "Fe",
    b: "CuSO₄",
    ratioA: 1,
    ratioB: 1,
    phenomenon: "Màu xanh nhạt dần, kim loại đỏ đồng xuất hiện",
    product: "Cu",
    color: "#bf7955",
  },
] as const;
export const chemistrySchema = z.object({
  reactionId: z.string().optional(),
  molesA: z.number().finite().min(0).max(2).optional(),
  molesB: z.number().finite().min(0).max(2).optional(),
  samples: z.record(z.enum(["acid", "neutral", "base"])).optional(),
});
export function chemistry(raw: unknown) {
  const s = chemistrySchema.parse(raw);
  if (s.samples) {
    const expected = { jar1: "acid", jar2: "neutral", jar3: "base" } as const;
    const samples = Object.entries(expected).map(([id, expectedType]) => ({ id, type: s.samples?.[id] ?? null, correct: s.samples?.[id] === expectedType }));
    const complete = samples.every((sample) => sample.type !== null);
    const passed = complete && samples.every((sample) => sample.correct);
    return {
      version: VERSION,
      experiment: "ph",
      samples,
      verdict: passed ? "passed" : complete ? "not_passed" : "partial",
      phenomenon: passed ? "Đã xác định đúng: lọ 1 là axit, lọ 2 trung tính, lọ 3 là bazơ." : "Hãy xác định đúng tính chất của cả ba lọ mất nhãn.",
    };
  }
  if (!s.reactionId || s.molesA == null || s.molesB == null) throw new Error("Thiếu dữ liệu thí nghiệm");
  const r = reactions.find((r) => r.id === s.reactionId);
  if (!r) throw new Error("Phản ứng chưa được hỗ trợ");
  const extent = Math.min(s.molesA / r.ratioA, s.molesB / r.ratioB);
  const remainingA = Math.max(0, s.molesA - extent * r.ratioA);
  const remainingB = Math.max(0, s.molesB - extent * r.ratioB);
  return {
    version: VERSION,
    ...r,
    extent,
    remainingA,
    remainingB,
    limiting:
      Math.abs(s.molesA / r.ratioA - s.molesB / r.ratioB) < 1e-9
        ? "balanced"
        : s.molesA / r.ratioA < s.molesB / r.ratioB
          ? r.a
          : r.b,
    verdict:
      extent <= 0
        ? "not_passed"
        : remainingA < 1e-9 && remainingB < 1e-9
          ? "passed"
          : "partial",
  };
}
export const eyeParts = [
  {
    id: "cornea",
    name: "Giác mạc",
    description: "Lớp trong suốt phía trước, khúc xạ ánh sáng đi vào mắt.",
  },
  {
    id: "aqueous",
    name: "Thủy dịch",
    description: "Dịch trong suốt giữa giác mạc và thể thủy tinh.",
  },
  {
    id: "pupil",
    name: "Đồng tử",
    description: "Lỗ ở giữa mống mắt cho ánh sáng đi qua.",
  },
  {
    id: "lens",
    name: "Thể thủy tinh",
    description: "Điều tiết để hội tụ ánh sáng lên võng mạc.",
  },
  {
    id: "vitreous",
    name: "Dịch kính",
    description: "Khối gel trong suốt duy trì hình dạng nhãn cầu.",
  },
  {
    id: "retina",
    name: "Võng mạc",
    description: "Lớp cảm thụ ánh sáng, chuyển thành tín hiệu thần kinh.",
  },
  {
    id: "nerve",
    name: "Dây thần kinh thị giác",
    description: "Dẫn truyền tín hiệu từ võng mạc đến não.",
  },
  {
    id: "sclera",
    name: "Củng mạc",
    description: "Lớp vỏ bảo vệ và duy trì hình dạng mắt.",
  },
];
export function eye(raw: unknown) {
  const s = z.object({ answers: z.record(z.string().max(100)) }).parse(raw);
  const normalize = (v: string) =>
    v.trim().toLocaleLowerCase("vi").normalize("NFC");
  const correct = eyeParts
    .filter((p) => normalize(s.answers[p.id] ?? "") === normalize(p.name))
    .map((p) => p.id);
  const score = Math.round((correct.length / eyeParts.length) * 100);
  return {
    version: VERSION,
    correct,
    score,
    verdict: score === 100 ? "passed" : score > 0 ? "partial" : "not_passed",
  };
}
export function simulate(labId: string, state: unknown) {
  if (labId === "circuit") return circuit(state);
  if (labId === "chemistry") return chemistry(state);
  if (labId === "eye") return eye(state);
  throw new Error("Lab không tồn tại");
}
